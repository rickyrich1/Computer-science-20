w1 = input("Number: ")
if w1[0]< w1[1] < w1[2]:
    print("yes")
else:
    print("No")
