w1 = int(input("Enter an integer: "))
w2 = int(input("Enter an integer: "))
if w1<w2:
    print(w1)
elif w1>w2:
    print(w2)
else:
    print("Both numbers are equal!")
