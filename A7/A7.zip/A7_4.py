w1 = len(input(""))
if w1==3:
    print("YES")
else:
    print("NO")
