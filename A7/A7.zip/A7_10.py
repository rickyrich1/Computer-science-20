num1 = int(input("first number: "))
num2 = int(input("second number: "))
if (num1 + num2) % 2 == 0:
    printn("Black")
else:
    print("White")
