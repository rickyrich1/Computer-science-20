w1 = input("")
if w1 == w1[::-1]:
    print("Yes")
else:
    print("No")
