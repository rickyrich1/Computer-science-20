w1 = int(input(" Enter an integer: ")
if w1>0
    print(1)
elif w1<0:
    print(-1)
else:
    print(0)
