w1 = int(input("A number: "))
w2 = int(input("Another number: "))
if w1>0:
    w2<0
    print("YES")
elif w1<0:
    w2>0
    print("YES")
elif w1<0:
    w2<0
    print("NO")
elif w1>0:
    w2>0
    print("NO")
else:
    print("NO")
