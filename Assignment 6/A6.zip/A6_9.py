w1 = input(" username: ")
w2 = w1.replace("@","")
print(w2)
