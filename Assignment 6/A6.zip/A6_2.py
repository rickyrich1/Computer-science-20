name = input("")
sl = name.count(" ")
print(sl+1)
