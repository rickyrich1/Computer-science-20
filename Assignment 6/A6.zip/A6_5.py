name = input("")
first = name.find("h")
last = name.rfind("h")
w1 = [0::4]
