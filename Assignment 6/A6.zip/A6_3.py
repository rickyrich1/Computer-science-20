name = input("")
si = name[::-1]
print(si)
