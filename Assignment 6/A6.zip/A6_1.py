name = input("put a name: ")
w1 = name[2]
w2 = name[-2]
w3 = name[:5]
w4 = name[:-2]
w5 = name[::2]
w6 = name[1::2]
w7 = name[::-1]
w8 = w5[::-1]
w9 = len(name)
print(w1)
print(w2)
print(w3)
print(w4)
print(w5)
print(w6)
print(w7)
print(w8)
print(w9)
