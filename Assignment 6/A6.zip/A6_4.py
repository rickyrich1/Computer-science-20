text = input("word: ")
mid = text.split(" ")
Q1 = mid[0]
Q2 = mid[1]
print(Q2, (Q1))
