name = input("word: ")
h1 = name.index("h")
h2 = name.rindex("h")
W1 = name[0:h1]
W2 = name[h1:h2+1]
